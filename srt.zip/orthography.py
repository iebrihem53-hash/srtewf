# -*- coding: utf-8 -*-
"""
orthography.py — Sorani Kurdish letter knowledge & normalization
================================================================
This module encodes deep, explicit knowledge of the Sorani (Central Kurdish)
alphabet and provides three things:

1. normalize(text)  — deterministic (100%-reliable) fixes: converts Arabic-form
   letters to their Kurdish equivalents, removes tatweel/zero-width marks,
   normalizes digits, spaces and punctuation. Preserves HTML tags and newlines.
   These are the letter mistakes that become IMPOSSIBLE to ship, because code —
   not a model — fixes them.

2. letter_audit(text) — flags any character that is NOT a valid Kurdish letter /
   digit / punctuation (e.g. a stray Arabic ث/ذ/ض, a leftover ي/ك, or Latin
   letters). This is how the system "knows and distinguishes every letter".

3. ORTH_GUIDE — an authoritative letter-distinction reference injected into the
   model prompts for the context-dependent choices that CANNOT be solved by a
   blind substitution (ی/ێ, و/ۆ/وو, ه/ە, ر/ڕ, ل/ڵ).

Honesty note: substitutions in group (1) are always safe. The distinctions in
group (3) are word-specific and are handled by the model + flagged for review
when uncertain — no lookup table can resolve them perfectly for every word.
"""

import re
import unicodedata
from typing import Dict, List, Set, Tuple

# --------------------------------------------------------------------------- #
#  The Sorani alphabet — every letter, its name and role
# --------------------------------------------------------------------------- #
# (letter, transliteration, role)
LETTERS: List[Tuple[str, str, str]] = [
    ("ئـ", "'", "hamza carrier — carries word-initial vowels (ئا ئە ئی ئێ ئۆ ئو)"),
    ("ا", "a",  "vowel â (long a); also bare alef mid/final"),
    ("ب", "b",  "consonant"),
    ("پ", "p",  "consonant"),
    ("ت", "t",  "consonant"),
    ("ج", "c",  "consonant (j)"),
    ("چ", "ç",  "consonant (ch)"),
    ("ح", "ḥ",  "consonant (pharyngeal h — loanwords)"),
    ("خ", "x",  "consonant"),
    ("د", "d",  "consonant"),
    ("ر", "r",  "consonant — single tap r (rarely word-initial)"),
    ("ڕ", "ř",  "consonant — strong trilled r (most word-initial r)"),
    ("ز", "z",  "consonant"),
    ("ژ", "j",  "consonant (zh)"),
    ("س", "s",  "consonant"),
    ("ش", "ş",  "consonant (sh)"),
    ("ع", "‘",  "consonant (pharyngeal — loanwords)"),
    ("غ", "ẍ",  "consonant (gh — loanwords)"),
    ("ف", "f",  "consonant"),
    ("ڤ", "v",  "consonant"),
    ("ق", "q",  "consonant"),
    ("ک", "k",  "consonant (Kurdish kaf — NOT Arabic ك)"),
    ("گ", "g",  "consonant"),
    ("ل", "l",  "consonant — plain l"),
    ("ڵ", "ł",  "consonant — velarized (dark) l"),
    ("م", "m",  "consonant"),
    ("ن", "n",  "consonant"),
    ("ه", "h",  "consonant h — the /h/ sound (NOT the vowel ە)"),
    ("ە", "e",  "vowel e/schwa — most final -e and many medial vowels"),
    ("و", "w/u","semivowel w and short vowel u"),
    ("وو", "û", "long vowel û (digraph)"),
    ("ۆ", "o",  "vowel o"),
    ("ی", "î/y","long vowel î and consonant y (Kurdish yeh — NOT Arabic ي)"),
    ("ێ", "ê",  "vowel ê (open e)"),
]

# Single valid Kurdish code points (digraph وو is two و).
KU_LETTER_SET: Set[str] = {
    "ئ", "ء", "ا", "ب", "پ", "ت", "ج", "چ", "ح", "خ", "د", "ر", "ڕ", "ز", "ژ",
    "س", "ش", "ع", "غ", "ف", "ڤ", "ق", "ک", "گ", "ل", "ڵ", "م", "ن", "ه", "ە",
    "و", "ۆ", "ی", "ێ",
}

# --------------------------------------------------------------------------- #
#  Deterministic, always-safe replacements
# --------------------------------------------------------------------------- #
SAFE_MAP: Dict[str, str] = {
    "\u064A": "ی",   # ARABIC YEH        ي → ی
    "\u0649": "ی",   # ALEF MAKSURA      ى → ی
    "\u06CC": "ی",   # FARSI YEH         ی → ی (canonical, no-op safety)
    "\u0643": "ک",   # ARABIC KAF        ك → ک
    "\u06A9": "ک",   # KEHEH             ک → ک (canonical)
    "\u0629": "ە",   # TEH MARBUTA       ة → ە
    "\u0647": "ه",   # ARABIC HEH        ه → ه (canonical; keep as consonant h)
    "\u06BE": "ه",   # HEH DOACHASHMEE   ھ → ه
    "\u0640": "",    # TATWEEL           ـ → (removed)
    "\u0622": "ئا",  # ALEF WITH MADDA    آ → ئا
    "\u0623": "ا",   # ALEF WITH HAMZA ABOVE  أ → ا
    "\u0625": "ئی",  # ALEF WITH HAMZA BELOW  إ → ئی
    "\u0624": "ئو",  # WAW WITH HAMZA        ؤ → ئو
    "\u0626": "ئ",   # YEH WITH HAMZA        ئ (bare, when not carrier) → ئ (canonical)
    "\u0621": "ئ",   # HAMZA                 ء → ئ
    # Arabic-only consonants → nearest Kurdish letter (these never belong in Kurdish)
    "\u062B": "س",   # THEH   ث → س
    "\u0630": "ز",   # THAL   ذ → ز
    "\u0635": "س",   # SAD    ص → س
    "\u0636": "د",   # DAD    ض → د
    "\u0637": "ت",   # TAH    ط → ت
    "\u0638": "ز",   # ZAH    ظ → ز
    "\u0671": "ا",   # ALEF WASLA ٱ → ا
    "\u0672": "ا", "\u0673": "ا", "\u0675": "ئ",
    # Arabic-Indic & extended digits are handled below; harakat stripped below.
    # NOTE: U+0626 handled above; U+0626 (ئ) IS the Kurdish hamza-carrier — the
    # mapping above is a canonical no-op that keeps it intact.
    # zero-width & bidi marks that corrupt rendering
    "\u200B": "",    # ZERO WIDTH SPACE
    "\u200E": "",    # LRM
    "\u200F": "",    # RLM
    "\uFEFF": "",    # BOM
    "\u00A0": " ",   # NBSP → normal space
    # Arabic harakat / tatweel-like marks → removed (never valid in Kurdish)
    "\u064B": "", "\u064C": "", "\u064D": "", "\u064E": "", "\u064F": "",
    "\u0650": "", "\u0651": "", "\u0652": "", "\u0653": "", "\u0654": "",
    "\u0655": "", "\u0656": "", "\u0657": "", "\u0658": "", "\u0670": "",
}

# Arabic-Indic digits → Kurdish (Eastern Persian) digits
_ARABIC_DIGITS = "٠١٢٣٤٥٦٧٨٩"      # U+0660..
_KURDISH_DIGITS = "۰۱۲۳۴۵۶۷۸۹"     # U+06F0..
for _a, _k in zip(_ARABIC_DIGITS, _KURDISH_DIGITS):
    SAFE_MAP[_a] = _k

# Allowed non-letter characters for the audit
_PUNCT = set("،؛؟!?.,:;…«»\"'“”‘’()[]{}-–—/\\&%٪*+=@#<>|~^ ")
_DIGITS = set("0123456789" + _KURDISH_DIGITS)
_WHITESPACE = set(" \n\t\u200c")  # ZWNJ (U+200C) is legitimate in Kurdish
AUDIT_ALLOWED: Set[str] = KU_LETTER_SET | _PUNCT | _DIGITS | _WHITESPACE

_TAG_SPLIT = re.compile(r"(<[^>]+>)")


def _apply_map(s: str) -> str:
    return "".join(SAFE_MAP.get(ch, ch) for ch in s)


def _normalize_segment(seg: str) -> str:
    seg = _apply_map(seg)
    seg = re.sub(r"[ \t]+", " ", seg)                 # collapse spaces (keep newlines)
    seg = re.sub(r"\s+([،؛؟!.,:;])", r"\1", seg)       # no space before punctuation
    seg = re.sub(r"([،؛])(?=\S)", r"\1 ", seg)          # one space after ، ؛
    return seg


def normalize(text: str) -> str:
    """Apply all deterministic, always-safe orthographic fixes.
    HTML tags and newline positions are preserved exactly."""
    if not text:
        return text
    # Compose to canonical NFC without the aggressive folding of NFKC.
    text = unicodedata.normalize("NFC", text)
    parts = _TAG_SPLIT.split(text)
    out = [
        p if (p.startswith("<") and p.endswith(">")) else _normalize_segment(p)
        for p in parts
    ]
    joined = "".join(out)
    # trim each line but keep the line structure
    return "\n".join(line.strip() for line in joined.split("\n")).strip()


def strip_tags(text: str) -> str:
    return re.sub(r"<[^>]+>", "", text or "")


def letter_audit(text: str) -> Dict[str, List[str]]:
    """Return any characters that are not valid Kurdish letters/digits/punct.
    Categorized so callers can act: 'latin' vs 'stray' (wrong Arabic-script)."""
    bare = strip_tags(text or "")
    latin: Set[str] = set()
    stray: Set[str] = set()
    for ch in bare:
        if ch in AUDIT_ALLOWED:
            continue
        if ("a" <= ch <= "z") or ("A" <= ch <= "Z"):
            latin.add(ch)
        elif unicodedata.category(ch).startswith(("L", "M")):
            # a letter/mark that isn't in the Kurdish set → wrong alphabet
            stray.add(ch)
        # symbols/others are ignored (rare, harmless)
    result: Dict[str, List[str]] = {}
    if latin:
        result["latin"] = sorted(latin)
    if stray:
        result["stray"] = sorted(stray)
    return result


# --------------------------------------------------------------------------- #
#  Letter-distinction guide for prompts (the context-dependent choices)
# --------------------------------------------------------------------------- #
ORTH_GUIDE = """KURDISH (SORANI) LETTER RULES — write every letter correctly:
Alphabet: ئـ ا ب پ ت ج چ ح خ د ر ڕ ز ژ س ش ع غ ف ڤ ق ک گ ل ڵ م ن ه ە و وو ۆ ی ێ
Never use Arabic forms: write ک (not ك), ی (not ي/ى); no tatweel (ـ).

Distinguish these correctly, per word:
• ه vs ە : ه is the CONSONANT /h/ (e.g. هەموو, مانگ + ه). ە is the VOWEL "e" — most word-final -e and many medial vowels (e.g. کوردە, ئەمە, دەکە). Do not swap them.
• ی vs ێ : ی = long "î" or consonant "y" (کوردی, یەک). ێ = "ê" (خێر, دەڵێ, ژێر). Choose by the actual vowel sound of the word.
• و vs ۆ vs وو : و = "w" or short "u" (وا, کورد). ۆ = "o" (خۆ, بۆ, ۆفیس). وو = long "û" (دوور, بوو, وردبوونەوە). Choose by sound.
• ر vs ڕ : ڕ = strong trilled r — used for MOST word-initial r (ڕۆژ, ڕەنگ, ڕێک) and where the trill is heard. ر = single tap (کار, سەر, دەرگا). 
• ل vs ڵ : ڵ = dark/velar l (باڵ, گەڵا, دڵ). ل = plain l (لە, گەل, ماڵ… note ماڵ uses ڵ). Choose by the word.
• Word-initial vowels take ئـ : ئاو, ئەو, ئێمە, ئۆتۆمبیل, ئومێد, ئینگلیزی.
Punctuation is Kurdish: ، ؟ ! — no space before, one space after ،."""


def build_letter_reference() -> str:
    """Human-readable full letter table (for docs / debugging)."""
    lines = ["Sorani letter inventory:"]
    for ch, tr, role in LETTERS:
        lines.append(f"  {ch}\t{tr}\t{role}")
    return "\n".join(lines)


def load_lexicon(path: str) -> Set[str]:
    """Load an optional Kurdish word list (one word per line, '#' comments).
    Words are normalized so comparison ignores Arabic-form differences.
    Returns an empty set if the file is missing — in that case spell-flagging
    is simply disabled (we never guess)."""
    words: Set[str] = set()
    try:
        with open(path, encoding="utf-8") as f:
            for line in f:
                w = line.strip()
                if w and not w.startswith("#"):
                    words.add(normalize(w))
    except Exception:
        pass
    return words


_WORD_RE = re.compile(r"[\u0621-\u06FF]+")

def kurdish_words(text: str) -> List[str]:
    return _WORD_RE.findall(strip_tags(text or ""))

def spell_flag(text: str, lexicon: Set[str]) -> List[str]:
    """Return whole words that are NOT in the supplied dictionary, for REVIEW.
    This never edits the text — it only points at words a human should check.
    Important: we deliberately do NOT auto-swap confusable letters (ی/ێ, ه/ە,
    ر/ڕ, ل/ڵ, و/ۆ) by rule, because a 'wrong' form is very often a different,
    perfectly valid word (e.g. لێ vs لە). Blind rules would create new errors,
    so context spelling is left to the model + this flag."""
    if not lexicon:
        return []
    bad = []
    for w in kurdish_words(text):
        if w not in lexicon and w not in bad:
            bad.append(w)
    return bad


if __name__ == "__main__":
    # quick self-test
    tests = [
        ("كوردیي ي ك", "کوردیی ی ک"),
        ("بەڵام ،وایە", "بەڵام، وایە"),
        ("<i>سڵاو ي</i>", "<i>سڵاو ی</i>"),
        ("دێڕی يەک\n دێڕی دوو ", "دێڕی یەک\nدێڕی دوو"),
        ("ژمارە ١٢٣", "ژمارە ۱۲۳"),
        ("ئازادـی", "ئازادی"),
    ]
    ok = True
    for src, want in tests:
        got = normalize(src)
        flag = "OK " if got == want else "FAIL"
        if got != want:
            ok = False
        print(f"[{flag}] {src!r} -> {got!r}" + ("" if got == want else f"  (want {want!r})"))
    print("audit('Hello جوان ث'): ", letter_audit("Hello جوان ث"))
    print("ALL PASSED" if ok else "SOME FAILED")
